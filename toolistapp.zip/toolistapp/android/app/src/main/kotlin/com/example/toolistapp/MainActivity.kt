package com.example.toolistapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
