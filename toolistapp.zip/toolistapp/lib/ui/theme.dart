import 'package:flutter/material.dart';
const Color bluishClr=Color(0×FF4e5ae8);
const Color yellowClr=Color(0×FFFF8746);
const Color pinkClr=Color(0×FFff4667);
const Color white= Colors.white;
const primaryClr=bluishClr;
const Color darkGreyClr=Color(0×FF121212);
Color darkHeaderClr =Color(0×FF424242);
class Themes{
  static final light= ThemeData(
  primaryColor: Colors.blue,
  brightness: Brightness.light
  );
  static final dark= ThemeData(
  primaryColor: darkGreyClr,
  brightness: Brightness.dark
  );
}